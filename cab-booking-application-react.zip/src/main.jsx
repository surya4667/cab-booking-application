import React,{useState} from "react";
import {createRoot} from "react-dom/client";
import "./style.css";

const rides=[
 {id:"mini",name:"Cab Mini",icon:"🚕",desc:"Affordable everyday ride",base:60,rate:14,eta:"3 min"},
 {id:"sedan",name:"Cab Sedan",icon:"🚘",desc:"Comfortable for 4 people",base:90,rate:18,eta:"5 min"},
 {id:"suv",name:"Cab SUV",icon:"🚙",desc:"More space for groups",base:130,rate:24,eta:"7 min"}
];

function App(){
 const [pickup,setPickup]=useState("");
 const [drop,setDrop]=useState("");
 const [selected,setSelected]=useState("mini");
 const [distance,setDistance]=useState(8);
 const [booked,setBooked]=useState(false);
 const [history,setHistory]=useState([]);
 const ride=rides.find(r=>r.id===selected);
 const fare=ride.base+distance*ride.rate;
 const book=()=>{
   if(!pickup||!drop){alert("Please enter pickup and destination.");return}
   const item={id:Date.now(),pickup,drop,car:ride.name,fare,eta:ride.eta};
   setHistory([item,...history]); setBooked(true);
 };
 return <div className="app">
  <header><div className="logo">🚕 <span>RideNow</span></div><div className="badge">Cab Booking</div></header>
  <main>
   <section className="hero"><div><p className="eyebrow">YOUR RIDE, YOUR WAY</p><h1>Book a cab in<br/><span>just a few clicks.</span></h1><p className="sub">Choose your pickup, destination and cab. Get an instant fare estimate.</p></div>
   <div className="heroCard"><div className="pin start">●</div><div className="routeLine"></div><div className="pin end">●</div><div className="locations"><input value={pickup} onChange={e=>setPickup(e.target.value)} placeholder="Pickup location"/><input value={drop} onChange={e=>setDrop(e.target.value)} placeholder="Where to?"/></div></div></section>
   <section className="content">
    <div className="left"><h2>Choose your ride</h2><div className="rideList">{rides.map(r=><button className={"ride "+(selected===r.id?"active":"")} onClick={()=>setSelected(r.id)} key={r.id}><span className="carIcon">{r.icon}</span><span className="rideText"><b>{r.name}</b><small>{r.desc}</small></span><span className="eta">{r.eta}</span></button>)}</div>
    <div className="distance"><label>Estimated distance</label><div><input type="range" min="1" max="40" value={distance} onChange={e=>setDistance(+e.target.value)}/><b>{distance} km</b></div></div>
    <h2>Booking summary</h2><div className="summary"><p><span>Pickup</span><b>{pickup||"Not selected"}</b></p><p><span>Destination</span><b>{drop||"Not selected"}</b></p><p><span>Vehicle</span><b>{ride.name}</b></p><p className="total"><span>Estimated fare</span><strong>₹{fare}</strong></p></div>
    <button className="book" onClick={book}>Book {ride.name} • ₹{fare}</button></div>
    <aside><div className="map"><div className="mapRoad r1"></div><div className="mapRoad r2"></div><div className="mapRoad r3"></div><div className="mapPin p1">A</div><div className="mapPin p2">B</div><div className="mapCar">🚕</div><span className="mapText">Route preview</span></div>
    {booked&&<div className="success"><b>✓ Ride booked!</b><span>Your {ride.name} is on the way. ETA {ride.eta}.</span></div>}
    <div className="history"><h3>Recent rides</h3>{history.length===0?<p>No rides booked yet.</p>:history.slice(0,3).map(x=><div className="historyItem" key={x.id}><span>🚕</span><div><b>{x.car}</b><small>{x.pickup} → {x.drop}</small></div><strong>₹{x.fare}</strong></div>)}</div></aside>
   </section>
  </main>
  <footer>© 2026 RideNow • React Cab Booking Application</footer>
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);